// Nombre: Fernando Buitrago Marin
// Descripción: Clase Producto con métodos

package actividad3_poo

class Producto(
    val nombre: String,
    var precio: Int,
    var stock: Int
) {

    fun vender(cantidad: Int): Boolean {
        if (cantidad <= 0) return false

        return if (stock >= cantidad) {
            stock -= cantidad
            true
        } else {
            false
        }
    }

    fun reponer(cantidad: Int) {
        if (cantidad > 0) {
            stock += cantidad
        }
    }

    fun info() = "$nombre | Precio: $precio | Stock: $stock"
}

fun main() {

    val p1 = Producto("Mouse", 50000, 10)
    val p2 = Producto("Teclado", 80000, 5)

    p1.vender(3)
    p2.vender(10)
    p2.reponer(8)

    println(p1.info())
    println(p2.info())
}



