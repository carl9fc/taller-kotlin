// Nombre: Fernando Buitrago Marin
// Fecha: 17/02/2026
// Descripción: Variables y funciones básicas

package actividad1_basicos

fun calcularIMC(pesoKg: Double, alturaM: Double): Double {
    return pesoKg / (alturaM * alturaM)
}

fun presentacion(nombre: String, edad: Int, ciudad: String): String {
    return "Hola, soy $nombre ($edad) de $ciudad."
}

fun main() {
    val nombre = "Fernando"
    val edad = 22
    val ciudad = "Manizales"
    val alturaM = 1.75
    val pesoKg = 70.0

    val imc = calcularIMC(pesoKg, alturaM)

    println(presentacion(nombre, edad, ciudad))
    println("IMC: %.2f".format(imc))
}


