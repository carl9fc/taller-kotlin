// Nombre: Fernando Buitrago Marin
// Descripción: Condicionales y nullabilidad

package actividad2_condicionales_null

fun calcularEnvio(distKm: Int, cupon: String?): Int {

    val tarifa = when {
        distKm < 5 -> 3000
        distKm <= 20 -> 7000
        else -> 12000
    }

    val c = cupon?.uppercase()

    return when (c) {
        "FREE" -> 0
        "HALF" -> tarifa / 2
        else -> tarifa
    }
}

fun main() {
    println(calcularEnvio(3, null))
    println(calcularEnvio(10, "half"))
    println(calcularEnvio(25, "FREE"))
}


