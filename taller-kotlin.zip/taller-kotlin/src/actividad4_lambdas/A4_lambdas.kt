// Nombre: Fernando Buitrago Marin
// Descripción: Lambdas y funciones de orden superior

package actividad4_lambdas

data class Producto(
    val nombre: String,
    val precio: Int,
    val stock: Int
)

fun filtrarProductos(
    productos: List<Producto>,
    criterio: (Producto) -> Boolean
): List<Producto> {
    return productos.filter(criterio)
}

fun main() {

    val lista = listOf(
        Producto("Laptop", 3000000, 3),
        Producto("Mouse", 40000, 0),
        Producto("Monitor", 900000, 2)
    )

    val caros = filtrarProductos(lista) { it.precio > 500000 }
    val sinStock = filtrarProductos(lista) { it.stock == 0 }

    println("Caros:")
    caros.forEach { println(it) }

    println("\nSin stock:")
    sinStock.forEach { println(it) }
}

